
import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import PrivacyPolicy from './components/PrivacyPolicy';
import WhatsAppButton from './components/WhatsAppButton';

const App: React.FC = () => {
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string>('');

  const handleServiceSelect = (service: string) => {
    setSelectedService(service);
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col relative">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Features onSelectService={handleServiceSelect} />
        <About />
        <Contact selectedService={selectedService} />
      </main>
      <Footer onOpenPrivacy={() => setIsPrivacyOpen(true)} />
      
      <WhatsAppButton />
      
      {isPrivacyOpen && (
        <PrivacyPolicy onClose={() => setIsPrivacyOpen(false)} />
      )}
    </div>
  );
};

export default App;
