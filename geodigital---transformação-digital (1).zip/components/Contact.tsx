
import React, { useState, useEffect } from 'react';
import { generateContactReply } from '../services/geminiService';

const services = [
    'Croquis de Localização Digital',
    'Criação de Carteiras Digitais',
    'Links Patrocinados (ADS)',
    'Criação de Apps Empresariais',
    'Criação de Sites Profissionais',
    'Gestão de Redes Sociais',
    'Outro'
];

interface ContactProps {
  selectedService?: string;
}

const Contact: React.FC<ContactProps> = ({ selectedService }) => {
  const initialFormState = {
    name: '',
    company: '',
    email: '',
    phone: '',
    service: services[0],
    message: ''
  };

  const [formData, setFormData] = useState(initialFormState);
  const [emailError, setEmailError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (selectedService && services.includes(selectedService)) {
      setFormData(prev => ({ ...prev, service: selectedService }));
    }
  }, [selectedService]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({...prev, [name]: value}));
    
    if (name === 'email' && emailError) {
      setEmailError('');
    }
  };

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleEmailBlur = () => {
    if (formData.email && !validateEmail(formData.email)) {
      setEmailError('Por favor, insira um endereço de email válido (ex: nome@empresa.com).');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateEmail(formData.email)) {
      setEmailError('Corrija o email antes de enviar.');
      const emailInput = document.getElementById('email');
      if (emailInput) emailInput.focus();
      return;
    }

    setIsLoading(true);

    try {
        // 1. Gerar a resposta da IA
        const generatedReply = await generateContactReply(formData.name, formData.message);

        // 2. Enviar o email para a empresa via AJAX (FormSubmit)
        const response = await fetch("https://formsubmit.co/ajax/geodigitalservico@gmail.com", {
            method: "POST",
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                ...formData,
                _subject: `Novo Pedido: ${formData.service} - ${formData.name}`,
                _template: "table",
                _captcha: "false"
            })
        });

        if (response.ok) {
            // Sucesso
            setAiResponse(generatedReply);
            setShowModal(true);
            setFormData(initialFormState); // Limpar formulário
        } else {
            throw new Error("Falha no envio para o servidor de email.");
        }

    } catch (error) {
        console.error(error);
        alert("Houve um erro ao enviar sua mensagem. Por favor, tente novamente ou use o WhatsApp.");
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <section id="contact" className="py-20 bg-slate-900 scroll-mt-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Entre em Contato</h2>
          <p className="text-slate-400 mt-4 max-w-2xl mx-auto">
            Tem uma ideia ou projeto? Adoraríamos ouvir sobre isso. Preencha o formulário para uma análise imediata ou use nossos contatos diretos.
            <br />
            <a href="mailto:geodigitalservico@gmail.com" className="text-[#2962FF] hover:underline">geodigitalservico@gmail.com</a> | WhatsApp: <a href="https://wa.me/244925251942" className="text-[#2962FF] hover:underline">+244 925 251 942</a>
          </p>
        </div>
        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">Nome*</label>
                <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    value={formData.name} 
                    onChange={handleChange} 
                    className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-[#7C4DFF] focus:border-[#7C4DFF] outline-none transition" 
                    required 
                    disabled={isLoading}
                />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-slate-300 mb-2">Empresa</label>
                <input 
                    type="text" 
                    id="company" 
                    name="company" 
                    value={formData.company} 
                    onChange={handleChange} 
                    className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-[#7C4DFF] focus:border-[#7C4DFF] outline-none transition" 
                    disabled={isLoading}
                />
              </div>
               <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">Email*</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    value={formData.email} 
                    onChange={handleChange}
                    onBlur={handleEmailBlur}
                    className={`w-full bg-slate-800 border rounded-md py-2 px-4 text-white focus:ring-2 outline-none transition ${
                      emailError 
                        ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                        : 'border-slate-600 focus:ring-[#7C4DFF] focus:border-[#7C4DFF]'
                    }`}
                    required 
                    disabled={isLoading}
                />
                {emailError && (
                  <p className="text-red-500 text-xs mt-1 font-medium animate-pulse">
                    {emailError}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-slate-300 mb-2">Telefone</label>
                <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    value={formData.phone} 
                    onChange={handleChange} 
                    className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-[#7C4DFF] focus:border-[#7C4DFF] outline-none transition" 
                    disabled={isLoading}
                />
              </div>
            </div>
             <div>
                <label htmlFor="service" className="block text-sm font-medium text-slate-300 mb-2">Serviço de Interesse</label>
                <select 
                    id="service" 
                    name="service" 
                    value={formData.service} 
                    onChange={handleChange} 
                    className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-[#7C4DFF] focus:border-[#7C4DFF] outline-none transition"
                    disabled={isLoading}
                >
                    {services.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">Mensagem*</label>
              <textarea 
                id="message" 
                name="message" 
                rows={5} 
                value={formData.message} 
                onChange={handleChange} 
                className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-[#7C4DFF] focus:border-[#7C4DFF] outline-none transition" 
                required
                disabled={isLoading}
              ></textarea>
            </div>
            
            <div className="text-center">
              <button 
                type="submit" 
                disabled={isLoading}
                className={`bg-[#2962FF] hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center justify-center mx-auto ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {isLoading ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processando com IA...
                    </>
                ) : (
                    'Enviar Mensagem'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* AI Response Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowModal(false)}></div>
            <div className="bg-slate-800 border border-[#7C4DFF]/50 rounded-xl shadow-2xl max-w-2xl w-full relative z-10 overflow-hidden transform transition-all animate-fade-in-up">
                <div className="bg-gradient-to-r from-[#7C4DFF] to-[#2962FF] p-4">
                    <h3 className="text-white font-bold text-xl flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Mensagem Recebida
                    </h3>
                </div>
                <div className="p-8">
                    <div className="mb-6">
                        <p className="text-slate-300 text-lg leading-relaxed whitespace-pre-line">
                            {aiResponse}
                        </p>
                    </div>
                    <div className="flex justify-end">
                        <button 
                            onClick={() => setShowModal(false)}
                            className="bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors"
                        >
                            Fechar
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}
    </section>
  );
};

export default Contact;
