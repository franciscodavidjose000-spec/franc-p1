
import React from 'react';
import { MapPinIcon } from './Icons';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-slate-800/30">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=2084&auto=format&fit=crop" 
              alt="Equipe GeoDigital"
              className="rounded-xl shadow-2xl"
            />
          </div>
          <div className="md:w-1/2">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Sobre a GeoDigital</h2>
            <p className="text-slate-400 mb-4 leading-relaxed">
              A GeoDigital é uma empresa dedicada à transformação digital de empresas de todos os portes. Combinamos competências em geotecnologias, desenvolvimento de aplicações e marketing digital para entregar soluções seguras, escaláveis e orientadas a resultados.
            </p>
            <p className="text-slate-400 leading-relaxed">
              O nosso foco é eficiência, inovação e suporte contínuo. Ajudamos negócios a crescer através de soluções tecnológicas acessíveis, modernas e eficientes, com o compromisso de entregar resultados reais com rapidez e profissionalismo.
            </p>
          </div>
        </div>

        <div className="mt-20">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h3 className="text-2xl font-bold text-[#7C4DFF] mb-3">Missão</h3>
                    <p className="text-slate-400">
                        Capacitar empresas com soluções digitais inovadoras e acessíveis, impulsionando seu crescimento e eficiência no mercado global.
                    </p>
                </div>
                <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h3 className="text-2xl font-bold text-[#7C4DFF] mb-3">Visão</h3>
                    <p className="text-slate-400">
                        Ser a principal referência em transformação digital, reconhecida pela excelência, resultados mensuráveis e parcerias de longo prazo.
                    </p>
                </div>
                <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h3 className="text-2xl font-bold text-[#7C4DFF] mb-3">Valores</h3>
                    <p className="text-slate-400">
                        Inovação, Compromisso com o Cliente, Integridade, Colaboração e Excelência.
                    </p>
                </div>
            </div>
        </div>

        <div className="mt-24">
          <div className="bg-slate-900/50 border border-slate-700 rounded-2xl p-8 md:p-10 shadow-xl relative overflow-hidden">
             <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-[#7C4DFF] rounded-full blur-3xl opacity-10"></div>
             <div className="flex flex-col md:flex-row items-center gap-10 relative z-10">
                <div className="md:w-1/3 flex flex-col items-center text-center">
                   {/* Avatar do Fundador */}
                   <div className="relative mb-4 group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-[#7C4DFF] to-[#2962FF] rounded-full opacity-70 blur transition duration-200 group-hover:opacity-100"></div>
                        <img 
                            src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=300&auto=format&fit=crop" 
                            alt="Francisco David José - Avatar Tech"
                            className="relative w-32 h-32 rounded-full object-cover border-2 border-slate-800 shadow-2xl"
                        />
                   </div>
                   
                   <h4 className="text-xl font-bold text-white">Francisco David José</h4>
                   <p className="text-[#7C4DFF] text-sm font-medium">Fundador</p>
                </div>
                <div className="md:w-2/3 text-center md:text-left">
                   <h3 className="text-2xl font-bold text-white mb-4">Origem & Sede</h3>
                   <p className="text-slate-300 mb-6 leading-relaxed">
                     Natural de Angola, da província do Zaire, município do Soyo. Francisco traz para a GeoDigital a visão de um futuro tecnológico integrado às necessidades locais e globais.
                   </p>
                   <div className="bg-slate-800 p-4 rounded-lg border border-slate-700/50 inline-flex flex-col sm:flex-row items-center sm:items-start gap-3">
                      <MapPinIcon className="h-6 w-6 text-[#7C4DFF] flex-shrink-0 mt-1" />
                      <div className="text-center sm:text-left">
                         <p className="text-white font-medium mb-1">Escritório e Sede</p>
                         <p className="text-slate-400 text-sm">Bairro 1º de Maio</p>
                         <p className="text-slate-400 text-sm">Município do Soyo, Província do Zaire, Angola</p>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default About;
