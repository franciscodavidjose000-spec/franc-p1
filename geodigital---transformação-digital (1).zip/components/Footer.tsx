
import React from 'react';
import { LinkedInIcon, FacebookIcon, InstagramIcon } from './Icons';

interface FooterProps {
  onOpenPrivacy: () => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenPrivacy }) => {
  return (
    <footer className="bg-slate-800/50 border-t border-slate-700/50">
      <div className="container mx-auto px-6 py-8 text-slate-400">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
            <div>
                <p>&copy; {new Date().getFullYear()} GeoDigital. Todos os direitos reservados.</p>
                <p className="text-sm mt-1">Levamos a sua empresa para o futuro.</p>
            </div>
            <div className="flex justify-center space-x-4 mt-6 md:mt-0">
                <a href="#" className="hover:text-[#7C4DFF] transition-colors duration-300">
                    <LinkedInIcon className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-[#7C4DFF] transition-colors duration-300">
                    <FacebookIcon className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-[#7C4DFF] transition-colors duration-300">
                    <InstagramIcon className="h-6 w-6" />
                </a>
            </div>
        </div>
        <div className="mt-6 pt-6 border-t border-slate-700/50 text-center text-sm">
            <button onClick={onOpenPrivacy} className="hover:text-white mx-2 transition-colors focus:outline-none">Política de Privacidade</button>
            <span className="mx-2">|</span>
            <a href="#" className="hover:text-white mx-2">Termos de Uso</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
