
import React from 'react';
import Card from './Card';
import { MapPinIcon, WalletIcon, ChartBarIcon, DevicePhoneMobileIcon, CodeBracketIcon, UsersIcon } from './Icons';

const featuresData = [
  {
    icon: <MapPinIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Croquis de Localização Digital',
    description: 'Criamos croquis profissionais e precisos para empresas, projetos e documentação pública ou privada.'
  },
  {
    icon: <WalletIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Criação de Carteiras Digitais',
    description: 'Desenvolvemos carteiras digitais seguras e práticas para pagamentos, fidelização e gestão interna.'
  },
  {
    icon: <ChartBarIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Links Patrocinados (ADS)',
    description: 'Gerimos campanhas de anúncios digitais para aumentar visibilidade, tráfego e vendas.'
  },
  {
    icon: <DevicePhoneMobileIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Criação de Apps Empresariais',
    description: 'Apps rápidas, intuitivas e adaptadas à realidade do teu negócio — Android, iOS e Web.'
  },
  {
    icon: <CodeBracketIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Criação de Sites Profissionais',
    description: 'Sites modernos, rápidos, responsivos e pensados para atrair mais clientes.'
  },
  {
    icon: <UsersIcon className="h-10 w-10 text-[#7C4DFF]" />,
    title: 'Gestão de Redes Sociais',
    description: 'Crescemos a tua presença digital com conteúdos estratégicos e gestão completa de perfis.'
  }
];

interface FeaturesProps {
  onSelectService: (service: string) => void;
}

const Features: React.FC<FeaturesProps> = ({ onSelectService }) => {
  return (
    <section id="features" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Nossos Serviços</h2>
          <p className="text-slate-400 mt-4 max-w-2xl mx-auto">
            Oferecemos um portfólio completo de soluções digitais para impulsionar o seu negócio na era da tecnologia.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuresData.map((feature, index) => (
            <Card 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              ctaText="Peça Orçamento"
              ctaLink="#contact"
              onCtaClick={() => onSelectService(feature.title)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
