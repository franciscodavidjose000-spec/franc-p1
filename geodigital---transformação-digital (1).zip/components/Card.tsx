
import React from 'react';

interface CardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  ctaText?: string;
  ctaLink?: string;
  onCtaClick?: () => void;
}

const Card: React.FC<CardProps> = ({ icon, title, description, ctaText, ctaLink, onCtaClick }) => {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (onCtaClick) {
      e.preventDefault();
      onCtaClick();
    }
  };

  return (
    <div className="bg-slate-800/50 p-8 rounded-xl shadow-lg hover:shadow-[#7C4DFF]/20 border border-slate-700/50 hover:border-[#7C4DFF]/50 transition-all duration-300 transform hover:-translate-y-2 flex flex-col">
      <div className="mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
      <p className="text-slate-400 flex-grow">{description}</p>
      {ctaText && (
        <div className="mt-6">
          <a 
            href={ctaLink || '#'} 
            onClick={handleClick}
            className="text-sm font-semibold text-[#7C4DFF] hover:text-[#9d7fff] transition-colors duration-300 cursor-pointer"
          >
            {ctaText} &rarr;
          </a>
        </div>
      )}
    </div>
  );
};

export default Card;
