
import React from 'react';

interface PrivacyPolicyProps {
  onClose: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-slate-800 border border-slate-700 rounded-xl shadow-2xl max-w-3xl w-full max-h-[80vh] overflow-y-auto relative z-10 flex flex-col">
        
        <div className="sticky top-0 bg-slate-800 p-6 border-b border-slate-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white">Política de Privacidade</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 text-slate-300 space-y-4 leading-relaxed">
          <p className="text-sm text-slate-500">Última atualização: {new Date().getFullYear()}</p>

          <p>
            A <strong>GeoDigital</strong> ("nós", "nosso" ou "nossa") valoriza a sua privacidade e está comprometida em proteger os seus dados pessoais. Esta Política de Privacidade explica como coletamos, usamos, divulgamos e protegemos as informações que você nos fornece ao usar nosso site e serviços.
          </p>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">1. Informações que Coletamos</h3>
          <p>Podemos coletar os seguintes tipos de informações:</p>
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>Informações Pessoais:</strong> Nome, endereço de e-mail, número de telefone, nome da empresa e outras informações que você fornece voluntariamente através de nossos formulários de contato.</li>
            <li><strong>Dados de Uso:</strong> Informações sobre como você acessa e usa o site, incluindo seu endereço IP, tipo de navegador, páginas visitadas e tempo gasto no site.</li>
          </ul>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">2. Como Usamos Suas Informações</h3>
          <p>Usamos as informações coletadas para:</p>
          <ul className="list-disc pl-5 space-y-2">
            <li>Fornecer e manter nossos serviços (Croquis, Apps, Sites, etc.).</li>
            <li>Responder às suas solicitações, perguntas e orçamentos.</li>
            <li>Melhorar a funcionalidade e a experiência do usuário em nosso site.</li>
            <li>Enviar comunicações importantes sobre atualizações de serviços ou mudanças nesta política.</li>
          </ul>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">3. Compartilhamento de Dados</h3>
          <p>
            Não vendemos, trocamos ou alugamos suas informações pessoais para terceiros. Podemos compartilhar informações apenas com prestadores de serviços confiáveis que nos auxiliam na operação do site e na condução de nossos negócios, desde que essas partes concordem em manter essas informações confidenciais.
          </p>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">4. Segurança dos Dados</h3>
          <p>
            Implementamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração, divulgação ou destruição. No entanto, nenhum método de transmissão pela Internet é 100% seguro.
          </p>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">5. Seus Direitos</h3>
          <p>
            Você tem o direito de solicitar acesso, correção ou exclusão de suas informações pessoais que mantemos. Para exercer esses direitos, entre em contato conosco através dos canais fornecidos abaixo.
          </p>

          <h3 className="text-xl font-semibold text-[#7C4DFF] mt-4">6. Contato</h3>
          <p>
            Se tiver dúvidas sobre esta Política de Privacidade, entre em contato conosco:
          </p>
          <p>
            Email: <a href="mailto:geodigitalservico@gmail.com" className="text-[#2962FF] hover:underline">geodigitalservico@gmail.com</a><br />
            WhatsApp: <a href="https://wa.me/244925251942" className="text-[#2962FF] hover:underline">+244 925 251 942</a>
          </p>
        </div>

        <div className="p-6 border-t border-slate-700 bg-slate-800 rounded-b-xl flex justify-end">
          <button 
            onClick={onClose}
            className="bg-[#2962FF] hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Entendi
          </button>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
