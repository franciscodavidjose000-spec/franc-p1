
import React from 'react';
import { WhatsAppIcon } from './Icons';

const WhatsAppButton: React.FC = () => {
  return (
    <a
      href="https://wa.me/244925251942"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 bg-[#25D366] text-white rounded-full shadow-xl hover:bg-[#20bd5a] hover:scale-110 hover:-translate-y-1 transition-all duration-300 group"
      aria-label="Conversar no WhatsApp"
    >
      <WhatsAppIcon className="h-8 w-8" />
      <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2 py-1 bg-slate-800 text-white text-xs font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none border border-slate-700 shadow-md">
        Fale Connosco
      </span>
      <div className="absolute inset-0 rounded-full border-2 border-white/20 animate-ping opacity-20"></div>
    </a>
  );
};

export default WhatsAppButton;
