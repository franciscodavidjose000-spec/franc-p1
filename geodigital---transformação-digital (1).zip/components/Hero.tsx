import React from 'react';

const Hero: React.FC = () => {
  const scrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative text-white py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900 to-slate-800 opacity-50"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1554494553-74a76b0e1346?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-10"></div>
      <div className="container mx-auto px-6 text-center relative z-10">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#7C4DFF] to-[#2962FF]">
          GeoDigital – Transformação Digital ao Alcance da Sua Empresa
        </h1>
        <p className="text-lg md:text-xl text-slate-300 max-w-3xl mx-auto mb-8">
          Soluções tecnológicas avançadas para negócios que querem crescer no ambiente digital.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href="#contact" 
              onClick={scrollToContact}
              className="bg-[#2962FF] hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg shadow-blue-500/30 w-full sm:w-auto cursor-pointer"
            >
              Solicitar Serviço
            </a>
            <a 
              href="https://wa.me/244925251942"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-transparent border-2 border-[#7C4DFF] hover:bg-[#7C4DFF] text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 w-full sm:w-auto"
            >
              Fale Connosco
            </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;