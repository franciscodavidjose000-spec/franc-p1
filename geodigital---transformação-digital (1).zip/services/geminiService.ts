import { GoogleGenAI } from "@google/genai";

export async function generateContactReply(name: string, userMessage: string): Promise<string> {
    try {
        // Inicialize o cliente dentro da função. Isso torna o tratamento de erros mais robusto
        // e alinha-se às melhores práticas para usar credenciais que podem ser fornecidas em tempo de execução.
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

        const systemInstruction = `
          Você é um assistente de suporte ao cliente para a empresa de tecnologia "GeoDigital".
          Sua tarefa é gerar respostas automáticas, amigáveis e profissionais em português.
          Seja conciso, mantenha um tom positivo e prestativo.
          Siga estritamente as instruções fornecidas.
        `;

        const prompt = `
          Gere uma resposta automática para um usuário chamado "${name}" que enviou a seguinte mensagem de contato:
          ---
          ${userMessage}
          ---

          Sua resposta DEVE seguir estas regras:
          1. Agradeça a ${name} pelo contato com a GeoDigital.
          2. Confirme que a mensagem dele(a) foi recebida com sucesso.
          3. Informe que a equipe da GeoDigital analisará a mensagem e responderá em breve (geralmente dentro de 24 horas úteis).
          4. Termine com uma saudação cordial: "Atenciosamente, Equipe GeoDigital".
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
            },
        });

        return response.text;
    } catch (error) {
        console.error("Error generating content with Gemini API:", error);
        throw new Error("Falha ao comunicar com a IA para gerar uma resposta.");
    }
}
